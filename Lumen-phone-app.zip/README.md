# Lumen

A free homework coach that teaches you step by step: a tutor with hints, a worksheet scanner, practice that checks your answers, flashcards, and predictions of what's coming next in class.

## Install it on your phone

**iPhone:** open the site in Safari → tap **Share** (or **⋯** → **Share**) → **Add to Home Screen** → **Add**.
**Android:** open it in Chrome → **⋮** → **Install app**.

It opens full screen with its own icon and works offline.

## Free AI

Lumen runs in Free mode: it only uses AI services that can't charge you. Add a free key in **More → Settings → AI**:

- **Google Gemini**: [aistudio.google.com/apikey](https://aistudio.google.com/apikey). Never turn on billing for that key's project. Google's terms require users to be 18+.
- **Groq**: [console.groq.com/keys](https://console.groq.com/keys)
- **OpenRouter**: [openrouter.ai/keys](https://openrouter.ai/keys) (Lumen only picks `:free` models)

Your key and your progress are stored only on your device. Requests go straight from your phone to the AI service you picked; nothing passes through this site.
